package com.lti.training.day4.assignment3;

public class TestClass {

	public static void main(String[] args) {
		  DisplayData d=new DisplayData();
		  d.display();

	}

}
