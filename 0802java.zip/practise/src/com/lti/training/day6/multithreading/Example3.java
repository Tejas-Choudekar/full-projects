package com.lti.training.day6.multithreading;

//import org.springframework.web.bind.annotation.ExceptionHandler;

class BankAccount{
	
	int acno;
	double balance;
	
	BankAccount (int acno, double balance){
		this.acno= acno;
		this.balance= balance;
	}
	
	//public void withdraw(double amount) {
	public synchronized void withdraw(double amount) {
		try {Thread.sleep(100);} catch (Exception e) {}
		if(amount<balance) {
			try {Thread.sleep(100);} catch (Exception e) {}
			balance -= amount;
			try {Thread.sleep(100);} catch (Exception e) {}
			System.out.println("Balance left "+ balance);
		}
		else
			System.out.println("Insufficient Balance!");
	}
	
}

class Transaction implements Runnable{
	
	BankAccount bankAccount;
	
	Transaction(BankAccount bankAccount){
		this.bankAccount= bankAccount;
	}
	
	@Override
	public void run() {
		bankAccount.withdraw(5000);
		/* we are calling withdraw method from inside the run method
		 *  because we want to make withdraw method multi-threaded*/
		
		
	}
	
}
public class Example3 {
	public static void main(String[] args) {
		BankAccount bankAcc = new BankAccount(1111, 6000);
		Transaction tx1 = new Transaction(bankAcc);
		Transaction tx2 = new Transaction(bankAcc);
		Thread th1= new Thread(tx1);
		Thread th2= new Thread(tx2);
		th1.start();
		th2.start();
		
	}
	
	/* The out put is either -4000 and -4000 or 1000 and 1000,
	 *  reason for this is the two threads are acting as two transactions
	 *   but they are occouring simultaneously so the balance is coming as 1000 even though
	 *   we have withdrew almost 10000, this is called concurrency issue.
	 *   i.e when two threads try to execute same object at the same time the output is unpredictable,
	 *   to avoid this we use synchronized keyword*/

}
