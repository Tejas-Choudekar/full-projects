package com.lti.training.devops.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataConnectivity {

	public void display() {
		Connection conn= null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn =DriverManager.getConnection("jdbc:oracle:thin:@infva06863:1521:xe","hr","hr");
			pstmt=conn.prepareStatement("select * from employees");
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				System.out.println(rs.getInt("employee_id")+"\t"+rs.getString("first_name")+"\t"+rs.getDouble("salary"));
			}
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {pstmt.close();} catch(Exception e) {}
			try {rs.close();} catch(Exception e) {}
			try {conn.close();} catch(Exception e) {}
		}
	}
	public static void main(String[] args) {
		DataConnectivity db=new DataConnectivity();
		db.display();
	}
}
