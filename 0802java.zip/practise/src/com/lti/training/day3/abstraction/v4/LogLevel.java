package com.lti.training.day3.abstraction.v4;

public enum LogLevel {
	INFO, WARN, ERROR;
}
