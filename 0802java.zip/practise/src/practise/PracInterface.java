package practise;

public interface PracInterface {
	public void Test (int a);
	public void Essay (int a);
	public void Cook (int a);
	public void Play (int a);
	
	
	default void  sleep(int b) {
		System.out.println("number is this: "+(b+20));
	}
	

}
