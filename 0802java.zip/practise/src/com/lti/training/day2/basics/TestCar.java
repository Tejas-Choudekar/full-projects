package com.lti.training.day2.basics;

import java.util.Date;

public class TestCar {
	public static void main(String[] args) {
		//create an object
		Car c1=new Car("RANGE ROVER","1996",100000);
		
		Date d1=new Date();
		System.out.println(d1.getHours()+";"+d1.getMinutes()+";"+d1.getSeconds());
		System.out.println(c1.getModel()+";"+c1.getPrice()+";"+c1.getYear());
		c1.setModel("Maruti 800");
		System.out.println(c1.getModel()+";"+c1.getPrice()+";"+c1.getYear());
		
		System.out.println(d1.getDate()+"--day--"+d1.getDay());
		Runtime r=Runtime.getRuntime();
		long total =r.totalMemory()/1024/1024;
		System.out.println("Total memory free"+r.freeMemory()/1024/1024);
		System.out.println("Total memory max"+r.maxMemory()/1024/1024);
		System.out.println("Total memory allocated in mb"+total);
	}

}
