package com.lti.training.day3.abstraction.v6;

public class TestLogger {

	public static void main(String[] args) {
		/*ConsoleLogger logger=new ConsoleLogger();
		FileLogger filelog=new FileLogger();
		logger.log("Some message");
		logger.log("Some message", LogLevel.WARN);
		logger.log("Some concern to be addressed", LogLevel.INFO);
		logger.log("Some critical situation has arised", LogLevel.ERROR);
		filelog.log("Some message");
		filelog.log("Some message", LogLevel.WARN);
		filelog.log("Some concern to be addressed", LogLevel.INFO);
		filelog.log("Some critical situation has arised", LogLevel.ERROR);
	*/
		Logger logger = LoggerFactory.getLoggerInstance();
		logger.log("Some message");
		logger.log("Some message", LogLevel.WARN);
		logger.log("Some concern to be addressed", LogLevel.INFO);
		logger.log("Some critical situation has arised", LogLevel.ERROR);
	}

}
