package com.lti.training.day4.asign;

import java.util.Arrays;

public class Toy implements Cloneable{
	private String name;
	private Battery[] batteries;
	private int count;
	
	public Toy()
	{
		
	}
	public Toy(String name,int noOfBatteries)
	{
		this.name=name;
		this.batteries=new Battery[noOfBatteries];
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Battery[] getBatteries() {
		return batteries;
	}
	public void setBatteries(Battery[] batteries) {
		this.batteries = batteries;
	}
	public void addBattery(String batteryName) {
		Battery battery= new Battery(batteryName);
		batteries[count++]= battery;
	}
	
	@Override
	public String toString() {
		return "Toy [name=" + name + ", batteries=" + Arrays.toString(batteries) + "]";
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		Toy t=(Toy)	super.clone();
		Battery[] newBattery=new Battery[batteries.length];
		for(int i=0;i<batteries.length;i++)
			newBattery[i]=(Battery) batteries[i].clone();
		t.setBatteries(newBattery);
		return t;
	}
}
