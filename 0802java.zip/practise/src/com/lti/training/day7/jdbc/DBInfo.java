package com.lti.training.day7.jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBInfo {

	public static void main(String[] args) {
		Connection conn=null;
		try {
			//Step 1. Loading JDBC driver
			Class.forName("oracle.jdbc.driver.OracleDriver");			//Reflection API
			//Step 2. Now we can try connecting to the database
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			String user="hr";
			String pass="hr";
			conn=DriverManager.getConnection(url, user, pass);
			
			DatabaseMetaData dbms=conn.getMetaData();			//DatabaseMetaData gives information about database
			System.out.println("DB Name: "+dbms.getDatabaseProductName());
			System.out.println("DB Version: "+dbms.getDatabaseProductVersion());
			
		}
		catch(ClassNotFoundException e) {
			System.out.println("Please check if the driver jar is present in the classpath");
		}
		catch(SQLException sqle) {
			sqle.printStackTrace();
		}
		finally {
			try { conn.close(); } catch(Exception ignore) { }
		}
	}
}
