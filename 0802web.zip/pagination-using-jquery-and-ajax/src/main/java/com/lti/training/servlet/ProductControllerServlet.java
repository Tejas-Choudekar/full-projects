package com.lti.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lti.training.dao.ProductDao;
import com.lti.training.model.Product;

/**
 * Servlet implementation class ProductControllerServlet
 */
@WebServlet("/ProductControllerServlet")
public class ProductControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int pageSize = 3;
		
		HttpSession session = request.getSession();	
		Integer currentPosition = (Integer) session.getAttribute("position");
		if(currentPosition == null)
			currentPosition=1;
		
		String go= request.getParameter("go");
		if(go != null) {
			if(go.equals("next"))
				currentPosition += pageSize;
			else if(go.equals("prev"))
				currentPosition -= pageSize;
		}
		else
			currentPosition=1;
		
		session.setAttribute("position", currentPosition);
		
		ProductDao dao = new ProductDao();
		List<Product> products = dao.fetchProducts(currentPosition, currentPosition+pageSize-1);
		
		//returning the products list in the form of a json
		//we will use jackson API for generating JSON from a Java object
		ObjectMapper mapper = new ObjectMapper(); //converts a java object into a json format
		String productsJSON = mapper.writeValueAsString(products); //taking products object in the form of string and converting it into json string
		
		response.setContentType("application/json");
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:4200");
		response.setHeader("Access-Control-Allow-Methods", "GET");
		PrintWriter out = response.getWriter();
		out.write(productsJSON);
	
	}

}
