package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.lti.entity.Songs;
import com.lti.util.JPAUtil;

public class AlbumDao extends GenericDao{	
	public List<Songs> fetchAlbum(int albid){
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		try {
			Query q = em.createQuery("select song from Songs as song join song.album alb where alb.album_id= :id");		//JPQL it is similar to select * of sql
			q.setParameter("id", albid);
			return q.getResultList();
		}
		finally {
			em.close();
		}
	}

}
