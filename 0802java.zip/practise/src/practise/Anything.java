package practise;

public class Anything implements PracInterface{
	public void Test(int a)
	{
		
	}
	public void Cook(int a)
	{
		
	}
	public void Essay(int a)
	{
		
	}
	public void Play(int a)
	{
		
	}
	public void sleep(int a)
	{
		System.out.println("Good night"+a);
	}
	public static void main(String[] args) {
		Anything a=new Anything();
		a.sleep(30);
	}
}
