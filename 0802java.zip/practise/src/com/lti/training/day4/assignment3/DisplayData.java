package com.lti.training.day4.assignment3;


/* String[][] data={
  {"P101", "Nokia Handset", "Some description", "2000.0"}
  {"P102", "Samsung Handset", "Description", "20000.0"}
  {"P103", "Sony Ericsson Handset", "Again Some description", "1500.0"}
  {"P104", "LG Handset", "No description", "1000.0"}};
  String[] colNames = {"ID", "Name", "Description", "Price"};*/

public class DisplayData {
	String[][] data={
			  {"P101", "Nokia Handset", "Some description", "2000.0"},
			  {"P102", "Samsung Handset", "Description", "20000.0"},
			  {"P103", "Sony Ericsson Handset", "Again Some description", "1500.0"},
			  {"P104", "LG Handset", "No description", "1000.0"}};
	
			  String[] colNames = {"ID", "Name", "Description", "Price"};
			  
			  public void display()
			  {
				  for(int i=0;i<colNames.length;i++)
				  {
					  System.out.print(colNames[i]+"\t");
				  }
				 System.out.println("");
				  for(int i=0;i<colNames.length;i++)
				  {
					  
					  for(int j=0;j<colNames.length;j++)
					  {
						  System.out.print(data[i][j]+"\t");
					  }
					  System.out.println();
				  }
			  }
}
