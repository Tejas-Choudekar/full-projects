package com.lti.training.day3.abstraction.v2;

public enum LogLevel {
	INFO, WARN, ERROR;
}
