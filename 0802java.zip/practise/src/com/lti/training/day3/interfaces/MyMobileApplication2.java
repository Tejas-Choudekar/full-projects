package com.lti.training.day3.interfaces;

public class MyMobileApplication2 implements MobileApplication {

	@Override
	public void start() {
		System.out.println("Mobile application 2 started...");
		
	}

	@Override
	public void pause() {
		System.out.println("Mobile application 2 paused...");
		
	}

	@Override
	public void stop() {
		System.out.println("Mobile application 2 stopped...");
		
	}

}
