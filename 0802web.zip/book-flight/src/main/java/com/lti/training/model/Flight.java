package com.lti.training.model;

public class Flight {
	private String From;
	private String To;
	private String Date;
	private int Flight_no;
	private String Flight_name;
	
	public String getFrom() {
		return From;
	}
	public void setFrom(String from) {
		From = from;
	}
	public String getTo() {
		return To;
	}
	public void setTo(String to) {
		To = to;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public int getFlight_no() {
		return Flight_no;
	}
	public void setFlight_no(int flight_no) {
		Flight_no = flight_no;
	}
	public String getFlight_name() {
		return Flight_name;
	}
	public void setFlight_name(String flight_name) {
		Flight_name = flight_name;
	}
	
}
