package com.lti.training.day5.wrapperclass;

public class BankAccount {

	private int acno;
	private String name;
	private double balance;
	public BankAccount(int acno, String name, double balance) {
		super();
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}
	
	public double withdraw(double amount) throws AccountException
	{
		if(amount>balance)
		{
			AccountException e=new AccountException("Insufficient Balance!");
			throw e;
		}
		else
		{
			balance-=amount;
			return balance;
		}
	}
	public static void main(String[] args) {
		BankAccount bankacc=new BankAccount(1001, "Tejas", 2000);
		try
		{
			double balance=bankacc.withdraw(6000);
			System.out.println("Balance left: "+balance);
		}
		catch(AccountException e)
		{
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}
	}
	
}
