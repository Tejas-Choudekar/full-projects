package com.lti.service;

import java.util.Date;
import java.util.List;

import com.lti.dao.AccountDao;
import com.lti.dao.GenericDao;
import com.lti.entity.Account;
import com.lti.entity.AccountTransaction;

//business logic is written here
public class AccountService {
	public void openAccount(String name, String type, double balance) {
		Account acc = new Account();
		acc.setName(name);
		acc.setType(type);
		acc.setBalance(balance);
		
		AccountDao dao= new AccountDao();
		dao.store(acc);
	}
	
	public void withdraw(int acno, double amount) {
		AccountDao dao= new AccountDao();
		Account acc= (Account) dao.fetchById(Account.class, acno);
		acc.setBalance(acc.getBalance()-amount);
		
		AccountTransaction tx= new AccountTransaction();
		tx.setAccount(acc);
		tx.setAmount(amount);
		tx.setDateandTime(new Date());
		tx.setType("Withdraw");
		
		dao.store(acc);
		dao.store(tx);
	}
	
	public void deposit(int acno, double amount) {
		AccountDao dao= new AccountDao();
		Account acc= (Account) dao.fetchById(Account.class, acno);
		acc.setBalance(acc.getBalance()+amount);
		
		AccountTransaction tx= new AccountTransaction();
		tx.setAccount(acc);
		tx.setAmount(amount);
		tx.setDateandTime(new Date());
		tx.setType("Deposit");
		
		dao.store(acc);
		dao.store(tx);
	}
	
	public void transfer(int fromacno, int toacno, double amount) {
		AccountDao dao= new AccountDao();
		Account fromacc= (Account) dao.fetchById(Account.class, fromacno);
		fromacc.setBalance(fromacc.getBalance()-amount);
		
		Account toacc= (Account) dao.fetchById(Account.class, toacno);
		toacc.setBalance(toacc.getBalance()+amount);
		
		AccountTransaction tx= new AccountTransaction();
		tx.setAccount(fromacc);
		tx.setAmount(amount);
		tx.setDateandTime(new Date());
		tx.setType("WithdrawFrom");
		dao.store(fromacc);
		
		AccountTransaction tx1= new AccountTransaction();
		tx1.setAccount(toacc);
		tx1.setAmount(amount);
		tx1.setDateandTime(new Date());
		tx1.setType("DepositTo");
		dao.store(toacc);
		
		dao.store(tx);
		dao.store(tx1);
	}
	
	public double balance(int acno) {
		AccountDao dao= new AccountDao();
		Account acc= (Account) dao.fetchById(Account.class, acno);
		return acc.getBalance();
	}

	public List<AccountTransaction> miniStament(int acno){
		AccountDao dao= new AccountDao();
		return dao.fetchMiniStatement(acno);
		
	}
	
	public List<Account> transactionFilter(String tx_type, double amount){
		AccountDao dao = new AccountDao();
		return dao.fetchAccounts(tx_type, amount);
	}
	
	public List<AccountTransaction> transactionDetails(String name){
		AccountDao dao = new AccountDao();
		return dao.fetchTransactions(name);
	}

}
