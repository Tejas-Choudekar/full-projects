package com.lti.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {

	public static EntityManagerFactory getEntityManagerFactory() { 
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate-oracle"); //<persistence-unit name="hibernate-oracle" transaction-type="RESOURCE_LOCAL"> 
		return emf;
	}
}
