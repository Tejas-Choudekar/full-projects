package com.lti.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="TBL_ACC")
public class Account {
	
	@Id
	@GeneratedValue
	private int acno;
	
	
	private String name;
	
	@Column(name="AC_TYPE")
	private String type;
	private double balance;
	
	@OneToMany(mappedBy="account")
	private Set<AccountTransaction> transactions;
	
}