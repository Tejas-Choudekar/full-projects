package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.junit.Test;
import com.lti.util.JPAUtil;

//persistence logic here
public class GenericDao <E>{

	
	public void store(Object obj) {
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();		
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx= em.getTransaction();
		tx.begin();
		em.merge(obj);
		//merge method is a 2 in one method
		//for transient - insert
		//for detach - update
		
		tx.commit();
		em.close();
	}
	
	
	
	//public Object fetchById(Class classname,Object pk)			this is non generic way
	public <E>E fetchById(Class<E>classname,Object pk) {
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		try {
			//Object e = em.find(classname, pk);			this is non generic way
			E e = em.find(classname, pk);			//It will fetch the data and will give us in the form of an object
			return e;
		}
		finally {
			em.close();
		}
	}
	
	@Test
	public <E>List<E> fetchAll(Class<E> Clazz){
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		try {
			Query q = em.createQuery("select clazz from"+Clazz.getName()+"as clazz");		//JPQL it is similar to select * of sql
			return q.getResultList();
		}
		finally {
			em.close();
		}
	}
	
}
