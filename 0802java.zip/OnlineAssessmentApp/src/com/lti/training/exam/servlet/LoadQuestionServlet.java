package com.lti.training.exam.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lti.training.exam.Question;
import com.lti.training.exam.QuestionBankLoader;


@WebServlet("/LoadQuestionServlet")
public class LoadQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		QuestionBankLoader loader = new QuestionBankLoader();
		List<Question> questions = loader.loadQuestionsOnJava();
		
		HttpSession session = request.getSession();			//making it workable in multithreaded environment, so we are creating session so questionNo can save the particular qstn no. for each user
		// checking if the question is already stores in the session
		Integer questionNo = (Integer) session.getAttribute("qNo");
		if (questionNo== null) {
			questionNo=0;		// starting from zero
		}
		else if(++questionNo == questions.size()) {
				response.sendRedirect("displayScore.jsp");
				return;
			
		}
		session.setAttribute("qNo", questionNo);
		Question question= questions.get(questionNo);
		session.setAttribute("currentQs", question);
		
		response.sendRedirect("showQuestion.jsp");
	}

}
