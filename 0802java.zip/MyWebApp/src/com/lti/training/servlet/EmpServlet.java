package com.lti.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmpServlet
 */
@WebServlet("/emp.xls")
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/vnd.ms-excel");				//MIME type, where application/<type> is the format for the pages which uses application to run
		PrintWriter out=response.getWriter();
		
		out.println("Empno\tName\tSalary");
		out.println("1001\tMajrul\t1000");
		out.println("1002\tDinesh\t2000");
		out.println("1003\tGaurav\t3000");
		out.println("1004\tNikhil\t4000");
		
		
	}

}
