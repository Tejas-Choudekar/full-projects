package com.lti.training.day3.objectclass;

public class Battery implements Cloneable {

	private int battery;
	public Battery( int x)
	{
		battery =x;
	}
	public int getBattery() {
		return battery;
	}
	public void setBattery(int battery) {
		this.battery = battery;
	}
	@Override
	public String toString() {
		return "Battery [battery=" + battery + "]";
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	
}
