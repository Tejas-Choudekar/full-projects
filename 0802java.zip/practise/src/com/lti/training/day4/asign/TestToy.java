package com.lti.training.day4.asign;

public class TestToy {

	public static void main(String[] args) throws CloneNotSupportedException {
		Toy t1= new Toy("RC Car", 6);
		t1.addBattery("Sony");
		t1.addBattery("Duracell");
		t1.addBattery("Exide");
		t1.addBattery("Nippo");
		t1.addBattery("Evaready");
		t1.addBattery("Nippo");
		 Toy t2= (Toy) t1.clone();
		 System.out.println(t1);
		 System.out.println(t2);
		

	}

}
