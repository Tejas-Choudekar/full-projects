package com.lti.training.day2.basics;

public class Car {
	//member variables/fields
	//instance variables/fields
	//non-static variables/fields
	//attributes
//member var represent	
	//the STATE of the object

	private String model;
	private String year;
	private double price;
	//------------------constructor(s)-------------------------//
	public Car(String model, String year, double price) {
		super();
		this.model = model;
		this.year = year;
		this.price = price;
	}
	//----------------------getters and setters----------------------//
	public String getModel() {
		return model;  //read
	}
	public void setModel(String model) {
		this.model = model;  //write
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	

	
}
