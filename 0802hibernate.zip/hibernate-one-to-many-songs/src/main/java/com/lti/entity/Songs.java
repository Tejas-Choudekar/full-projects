package com.lti.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tbl_songs")
public class Songs {
	
	@Id
	@GeneratedValue
	private int song_id;
	private String name;
	private double duration;
	private String singer;
	
	@ManyToOne
	@JoinColumn(name="album_id")
	private Albums album;

	public int getSong_id() {
		return song_id;
	}

	public void setSong_id(int song_id) {
		this.song_id = song_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public Albums getAlbum() {
		return album;
	}

	public void setAlbum(Albums album) {
		this.album = album;
	}

	@Override
	public String toString() {
		return "Songs [song_id=" + song_id + ", name=" + name + ", duration=" + duration + ", singer=" + singer
				+ ", album=" + album + "]";
	}
	
	
}
