package com.lti.training.day3.interfaces;

public class MyMobileApplication implements MobileApplication {

	@Override
	public void start() {
		System.out.println("Mobile application started...");
		
	}

	@Override
	public void pause() {
		System.out.println("Mobile application paused...");
		
	}

	@Override
	public void stop() {
		System.out.println("Mobile application stopped...");
		
	}

}
