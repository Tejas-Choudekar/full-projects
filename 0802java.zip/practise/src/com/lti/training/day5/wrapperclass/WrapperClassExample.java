package com.lti.training.day5.wrapperclass;

public class WrapperClassExample {

	public static void main(String[] args) {
		int x=10;
		Integer y=20;				//autoboxing
		Integer z=new Integer(30);		
		
		int a=10;
		a=20;
		
		Integer b=10;		//new object is created
		b=20;			//new object is created again
		
		//int c=null;		//primitive type cannot store null value
		Integer d=null;	//Wrapper classes can store null value
		
		//converting int to Integer
		Integer e=10;
		
		//converting Integer to int
		int f=e;
		//converting String to Integer
		Integer g=new Integer("100");
		//converting Integer to String 
		String h=g.toString();
		//converting String to int
		int i=Integer.parseInt("100");
		//converting int to String
		String j=Integer.toString(100);
		
		int k=20;
		System.out.println(k+" int");
		String l=Integer.toString(k);
		System.out.println(l+" String");
		float m=Float.parseFloat(l);
		System.out.println(m+" float");
		Double n=new Double(m);
		System.out.println(n+" Double");
		Integer o=n.intValue();
		System.out.println(o+" Integer");
		
		
	}
}
