package com.lti.training.servlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CaptchaServlet
 */
@WebServlet("/captcha.jpg")
public class CaptchaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("image/jpeg");
		ServletOutputStream out = response.getOutputStream();		//io class for image streaming
		String str= "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		String capchaText="";
		Random random = new Random();
		//random.nextInt(62);
		for(int i=0; i<5; i++)
		{
			int rno= random.nextInt(62);
			capchaText += str.charAt(rno);
		}
		
		BufferedImage img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
		Graphics g = img.getGraphics();
		g.setColor(Color.GREEN);
		g.fillRect(0, 0, 100, 100);
		g.setColor(Color.RED);
		g.setFont(new Font("Harrington",Font.BOLD, 28));
		g.drawString(capchaText, 50, 50);
		
		ImageIO.write(img, "jpeg", out);
	}


}
