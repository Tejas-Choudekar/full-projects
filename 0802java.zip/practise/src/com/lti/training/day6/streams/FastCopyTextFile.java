package com.lti.training.day6.streams;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/*
 * This program copies the data of one text file to another using buffering
 */
public class FastCopyTextFile {
	
	public static void main(String[] args) {
		FileReader inFile = null;
		FileWriter outFile= null;
		BufferedReader inBuffer=null;
		BufferedWriter outBuffer=null;
		
		try {
			inFile = new FileReader("sample.txt");
			outFile = new FileWriter("outsample.txt");
			
			inBuffer=new BufferedReader(inFile);  //default size of buffer us 8kb
			outBuffer=new BufferedWriter(outFile);

			String line = null;
			while(true) {
				line= inBuffer.readLine();
				if(line== null)	//End Of File
					break;
				outBuffer.write(line.toUpperCase());
				outBuffer.newLine();		//to add generated character on new line.
				System.out.println(line);		
			}
			System.out.println("File copy jhali!!!");
		}
		catch(FileNotFoundException e) {
			System.out.println("Please check the no. of your glasses");
		}
		catch(IOException e) {
			System.out.println("Please contact Mr. Santosh, HDD corrupted");
		}
		finally {
			try { inBuffer.close();} catch (Exception e) {}
			try { outBuffer.close();} catch (Exception e) {}
			try { inFile.close();} catch (Exception e) {}
			try { outFile.close();} catch (Exception e) {}
		}
	}
}

/* Know where to use InputStream OutputStream and reader writer,
 * Inpurstream Outputstream reads data in bit by bit form but reader writer uses char by char i.e byte by byte
 * so using reader/writer for jpg or any non text file handeling may cause error. so be careful.*/





