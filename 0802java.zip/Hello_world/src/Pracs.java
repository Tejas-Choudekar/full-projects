
public class Pracs {

	public static void main(String[] args) {
	Double obj= new Double("2.4");
	int a= obj.intValue();
	byte  b=obj.byteValue();
	float d =obj.floatValue();
	double c= obj.doubleValue();	
	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	System.out.println(d);
	System.out.println(a+b+c+d);
	}

}
