package com.lti.training.day3.interfaces;

public class TaskManager {

		private MobileApplication[] runningApp;
		private int count;
		
		public TaskManager()
		{
			runningApp=new MobileApplication[100];
		}
		public void newAppLoaded(MobileApplication mobileApp)
		{
			runningApp[count++]=mobileApp;
		}
		public int getNumberOfRunningApps()
		{
			return count;
		}
		public void closedRunningApps()
		{
			for(int i=0;i<count;i++)
				runningApp[i].stop();
			count=0;
		}
}
