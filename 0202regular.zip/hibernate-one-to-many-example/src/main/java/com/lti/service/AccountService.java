package com.lti.service;

//business logic is written here
public class AccountService {
	public void openAccount(String name, String type, double balance) {
		
	}
	
	public void withdraw(int acno, double amount) {
		
	}
	
	public void deposit(int acno, double amount) {
			
	}
	
	public void transfer(int fromacno, int toacno, double amount) {
		
	}
	
	public double balance(int acno) {
		
	}


}
