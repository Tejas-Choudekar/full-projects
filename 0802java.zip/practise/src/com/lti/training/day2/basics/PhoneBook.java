package com.lti.training.day2.basics;

public class PhoneBook {
	private Contact[] contacts;
	private int count;
//default constructor
	public PhoneBook() {
		contacts=new Contact[100];
	}
	// parameterized constructor
	public PhoneBook(int noOfEntries) {
		contacts=new Contact[noOfEntries];
	}
	
	public void add(Contact contact) 
	{ 
		contacts[count++]=contact;	
	}
	public void Display() {
		for(int i=0;i<count;i++)
		System.out.println("Name-"+contacts[i].getName()+"\t  Number-"+contacts[i].getNumber()+"\tEmail-"+contacts[i].getEmail()+"\tDOB-"+contacts[i].getDob());
	}
	public Contact  searchByName(String name)
	{
		
		for(int i=0;i<count;i++) 
			if(contacts[i].getName().equals(name))
		return contacts[i];
		return null;
	}
	public Contact  searchByNumber(String number)
	{
		
		for(int i=0;i<count;i++) 
			if(contacts[i].getName().equals(number))
			return contacts[ i];
		return null;
	}
	public  void update(Contact contact)
	
	{
		for(int i=0;i<count;i++) {
			if(contacts[i].getName().equals(contact.getName()))
			{
				 contacts[i] = contact;
				 
			}
		}
		
	}
	public void clear()
	{
		
	}
}
