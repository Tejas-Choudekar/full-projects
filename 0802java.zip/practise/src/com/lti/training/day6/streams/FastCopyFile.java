package com.lti.training.day6.streams;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/*
 * This program copies the data of one file to another using buffering
 */
public class FastCopyFile {
	
	public static void main(String[] args) {
		FileInputStream inFile = null;
		FileOutputStream outFile= null;
		BufferedInputStream inBuffer=null;
		BufferedOutputStream outBuffer=null;
		
		try {
			inFile = new FileInputStream("D:\\jdk-8u131-windows-x64.exe");
			outFile = new FileOutputStream("D:\\\\jdk-8u131-windows-x64-copy-copy.exe");
			
			inBuffer=new BufferedInputStream(inFile);  //default size of buffer us 8kb
			outBuffer=new BufferedOutputStream(outFile);

			int ch=0;
			while(true) {
				ch= inBuffer.read();
				if(ch== -1)	//End Of File
					break;
				outBuffer.write(ch);
				//System.out.print((char)ch);		
			}
			System.out.println("File copy jhali!!!");
		}
		catch(FileNotFoundException e) {
			System.out.println("Please check the no. of your glasses");
		}
		catch(IOException e) {
			System.out.println("Please contact Mr. Santosh, HDD corrupted");
		}
		finally {
			try { inBuffer.close();} catch (Exception e) {}
			try { outBuffer.close();} catch (Exception e) {}
			try { inFile.close();} catch (Exception e) {}
			try { outFile.close();} catch (Exception e) {}
		}
	}
}

/* Know where to use InputStream OutputStream and reader writer,
 * Inpurstream Outputstream reads data in bit by bit form but reader writer uses char by char i.e byte by byte
 * so using reader/writer for jpg or any non text file handeling may cause error. so be careful.*/


