package com.lti.training.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.training.service.DatabaseUserService;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String cnf_password=request.getParameter("cnf_password");
		
		DatabaseUserService userService = new DatabaseUserService();
		 boolean isPasswordValid = userService.validatePassword(password,cnf_password);
		 
		 if(isPasswordValid) {
			 userService.addData(username, password);
			 response.sendRedirect("login.html");
		 }
		 else {
			 response.sendRedirect("registeration.html");
		 }
	}

}
