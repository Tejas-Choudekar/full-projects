package com.lti.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.lti.dao.CustomerDao;
import com.lti.entity.Customer;

public class CustomerTest {

	@Test
	public void addCustomer(){
		Customer c = new Customer();
		c.setName("Donald Trump");
		c.setEmail("DonaldTrump@goawaymexicans.com");
		CustomerDao dao = new CustomerDao();
		dao.store(c);
		
		//asserts are missing 
	}
	
	@Test
	public void fetchCustomer() {
		CustomerDao dao= new CustomerDao();
		Customer c= dao.fetchById(21);
		assertNotNull(c);
		assertEquals("Donald Trump", c.getName());
		assertEquals("DonaldTrump@goawaymexicans.com", c.getEmail());
	}
	
	@Test
	public void fetchAll() {
		CustomerDao dao= new CustomerDao();
		List<Customer> list = dao.fetchAll();
		assertNotNull(list);
		assertEquals(5, list.size());
	}
}
