package com.lti.training.day3.abstraction.v5;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

/**
 * A simple implementation of logging in Java
 * @author Tejas
 * @version 1.0
 */
public class FileLogger extends Logger {

	@Override
	public void log(String msg, LogLevel level)
	{
		try(FileWriter fw=new FileWriter("app.log",true))				// app.log is the name of the file and true indicates that file is opened in append mode and it will keep on adding data in the same class(append)
		{
				switch(level)
				{
					case INFO:
						fw.write("[INFO] ["+LocalDateTime.now()+"]"+" "+msg+"\n");
						break;
					case WARN:
						fw.write("[WARNING] ["+LocalDateTime.now()+"]"+" "+msg+"\n");
						break;
					case ERROR:
						fw.write("[ERROR] ["+LocalDateTime.now()+"]"+" "+msg+"\n");
						break;
				}
			}
			catch(IOException e)
			{
				e.printStackTrace();					//Used for tracing back the data, and knowing where exactly the error occured in case of program stopping abruptly
			}
	}
}
