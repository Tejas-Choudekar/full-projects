package com.lti.training.day6.streams;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadFile {
	
	public static void main(String[] args) {
		FileInputStream inFile = null;
		try {
			inFile = new FileInputStream("sample.txt");
			int ch=0;
			while(true) {
				ch= inFile.read();
				if(ch== -1)	//End Of File
					break;
				System.out.print((char)ch);
			}
		}
		catch(FileNotFoundException e) {
			System.out.println("Please check the no. of your glasses");
		}
		catch(IOException e) {
			System.out.println("Please contact Mr. Santosh, HDD corrupted");
		}
		finally {
			try { inFile.close();} catch (Exception e) {}
				// TODO: handle exception
			}
		}
	}


