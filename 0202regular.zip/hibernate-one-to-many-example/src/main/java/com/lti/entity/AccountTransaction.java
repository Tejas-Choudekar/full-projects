package com.lti.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="TBL_ACC_TX")
public class AccountTransaction {
	
	@Id
	@GeneratedValue
	private int txno;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateandTime;
	
	private double amount;
	
	
	@Column(name="TX_TYPE")
	private String type;
	
	@ManyToOne
	@JoinColumn(name="acno")
	private Account account;
	
}
