package com.lti.test;

import java.util.Date;

import org.junit.Test;

import com.lti.entity.Albums;
import com.lti.entity.Songs;
import com.lti.service.Service;

public class AlbumTest {

	@Test
	public void addAlbum() {
		Service sc = new Service();
		sc.addAlbum("Hybrid Theory", new Date(), "Linkin Park");
		sc.addAlbum("Insomniac", new Date(), "Green day");
		sc.addAlbum("Rust in peace", new Date(), "Megadeath");
	}
	
	
	@Test
	public void addSongs() {
		Service sc = new Service();
		sc.addSongs("In the end", 05.82, "Chester Bennington", 83);
		sc.addSongs("What i've done", 06.72, "Chester Bennington", 83);
		sc.addSongs("Crawling", 05.13, "Chester Bennington", 83);
		sc.addSongs("Brain Stew", 03.57, "Billy Joe Armstrong", 84);
		sc.addSongs("Holy wars", 06.34, "Dave Mustaine", 85);
		sc.addSongs("Venom", 05.57, "Eminem", 81);
	}
	
	
	@Test
	public void fetchAlbum() {
		Service sc= new Service();
		for(Songs alb: sc.fetchAlbum(83))
			System.out.println(alb);
	}
}
