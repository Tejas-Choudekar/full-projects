package com.lti.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="tbl_album")
public class Albums {
	
	@Id
	@GeneratedValue
	private int album_id;
	
	private String name;
	
	private Date release_date;
	
	private String copyright;
	
	@OneToMany(mappedBy="album")
	private Set<Songs> songs;

	public int getAlbum_id() {
		return album_id;
	}

	public void setAlbum_id(int album_id) {
		this.album_id = album_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getRelease_date() {
		return release_date;
	}

	public void setRelease_date(Date release_date) {
		this.release_date = release_date;
	}

	public String getCopyright() {
		return copyright;
	}

	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	public Set<Songs> getSongs() {
		return songs;
	}

	public void setSongs(Set<Songs> songs) {
		this.songs = songs;
	}

	@Override
	public String toString() {
		return "Albums [album_id=" + album_id + ", name=" + name + ", release_date=" + release_date + ", copyright="
				+ copyright + "]";
	}
	
	
}
