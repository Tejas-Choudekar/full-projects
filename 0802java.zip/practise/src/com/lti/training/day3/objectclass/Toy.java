package com.lti.training.day3.objectclass;

import java.util.Arrays;

public class Toy implements Cloneable {
	private Battery bat[];
	private int count;
	
	public Toy()
	{
		bat=new Battery[3];
	}
	
	public Toy(Battery[] bat) {
		super();
		this.bat = bat;
	}
	
	public Battery[] getBat() {
		return bat;
	}

	public void setBat(Battery[] bat) {
		this.bat = bat;
	}

	public void add(Battery bat)
	{
		this.bat[count++]=bat;
	}

	@Override
	public String toString() {
		return "Toy [bat=" + Arrays.toString(bat) + "]";
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}
