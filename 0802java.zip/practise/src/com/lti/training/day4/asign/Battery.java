package com.lti.training.day4.asign;

public class Battery implements Cloneable{

	private static int seq=1;
	private int battery_no;
	private String name;
	public Battery()
	{
		
	}
	public Battery(String name) {
		super();
		this.battery_no = seq++;
		this.name = name;
	}
	public int getBattery_no() {
		return battery_no;
	}
	public void setBattery_no(int battery_no) {
		this.battery_no = battery_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Battery [battery_no=" + battery_no + ", name=" + name + "]";
	}
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	
}
