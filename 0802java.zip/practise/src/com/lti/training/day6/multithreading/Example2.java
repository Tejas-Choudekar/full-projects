package com.lti.training.day6.multithreading;

public class Example2 {

	class SomeTask implements Runnable{
		public void run() {
			System.out.println("Line 1 executed");
			try {
				Thread.sleep(1000*60*60);
			}
			catch(InterruptedException e) {
				System.out.println("Kisne mujhe jagaya????");
			}
			System.out.println("Line 2 executed");
		}
	}
	
	void launch() {
		Thread t=new Thread(new SomeTask());
		t.start();
		try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
		}
		t.interrupt();
	}
	
	public static void main(String[] args) {
		new Example2().launch();
	}
}
