package com.lti.util;

/*As we might call emf object multiple times but we only need to make only one instance of this in memory 
 * so we are making this class a singleton class to save memory.*/

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {

	private static EntityManagerFactory emf=null;		//using these non commmented code to make this class a singleton
	static {
		emf=Persistence.createEntityManagerFactory("hibernate-oracle");
	}
	public static EntityManagerFactory getEntityManagerFactory() { 
		/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate-oracle"); //<persistence-unit name="hibernate-oracle" transaction-type="RESOURCE_LOCAL"> 
		return emf;*/		//these  two statements were not making this class a singelton
		
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				emf.close();
			}
		});
		return emf;
	}
}
