package com.lti.training.day6.multithreading;

public class Example1 {

	//inner classes
	class Task1 implements Runnable{
		@Override
		public void run() {
			for(int i=0;i<1000000;i++) {
				System.out.println("Task1 running ");
				//Thread.sleep(100);
			//try { Thread.sleep(1);} catch(InterruptedException e) {}
				Thread.yield();
			}
		}
	}
	
	class Task2 implements Runnable{
		@Override
		public void run() {
			for(int i=0;i<1000000;i++)
			{
				System.out.println("Task2 running ");
				//try { Thread.sleep(1);} catch(InterruptedException e) {}
				Thread.yield();
				
			}
			}
	}
	
	private void launch() {
		Task1 task1=new Task1();
		Task2 task2=new Task2();
		Thread t1=new Thread(task1);
		Thread t2=new Thread(task2);
		//t1.setPriority(Thread.MIN_PRIORITY);
		//t2.setPriority(Thread.MAX_PRIORITY);
		//t1.setPriority(1);
		//t2.setPriority(10);
		//t1.setDaemon(true);
		//t2.setDaemon(true);
		t1.start();
		t2.start();
	}
	
	public static void main(String[] args) {
		new Example1().launch();
		System.out.println("Main function terminated");
	}
}
