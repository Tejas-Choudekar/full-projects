package com.lti.training.day3.abstraction.v1;

public enum LogLevel {
	INFO, WARN, ERROR;
}
