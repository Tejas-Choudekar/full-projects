package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.lti.entity.Account;
import com.lti.entity.AccountTransaction;
import com.lti.util.JPAUtil;

public class AccountDao extends GenericDao{
	public List<AccountTransaction> fetchMiniStatement(int acno){
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		try {
			String jpql = "select act from AccountTransaction as act where act.account.acno = :acc order by act.dateandTime desc";
			Query q = em.createQuery(jpql);		//JPQL it is similar to select * of sql
			q.setParameter("acc", acno);
			q.setMaxResults(5);
			
			return q.getResultList();
		}
		finally {
			em.close();
		}
	}
	
	//select acc.* from tbl_acc acc, tbl_acc_tx tx where tx.amount>1000 and acc.acno=tx.acno;
	public List<Account> fetchAccounts(String txType, double amount){
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		try {
			String jpql = "select acc from Account as acc inner join acc.transactions tx where tx.amount>= :amount and tx.type= :type";
			Query q = em.createQuery(jpql);		//JPQL it is similar to select * of sql
			q.setParameter("amount", amount);
			q.setParameter("type", txType);
			
			return q.getResultList();
		}
		finally {
			em.close();
		}
	}
	
	// select tx.* from tbl_acc_tx tx, tbl_acc ac where ac.acno=tx.acno and ac.name='John';
	public List<AccountTransaction> fetchTransactions(String name){
		EntityManagerFactory emf = JPAUtil.getEntityManagerFactory();
		EntityManager em = emf.createEntityManager();
		try {
			String jpql = "select tx from AccountTransaction as tx inner join tx.account txa where txa.name= :name";
			Query q = em.createQuery(jpql);		//JPQL it is similar to select * of sql
			q.setParameter("name", name);
			
			return q.getResultList();
		}
		finally {
			em.close();
		}
	}
	
}
