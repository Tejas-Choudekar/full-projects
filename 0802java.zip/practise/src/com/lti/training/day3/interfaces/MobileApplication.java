package com.lti.training.day3.interfaces;

/**
 * 
 * @author google
 *
 */

public interface MobileApplication {
	
	public void start();
	public void pause();
	public void stop();
	
}
