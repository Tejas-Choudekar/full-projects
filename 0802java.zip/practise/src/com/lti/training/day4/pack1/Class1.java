package com.lti.training.day4.pack1;

public class Class1 {
	
	private int a=10;
	int b=20;
	protected int c=30;
	public int d=40;

}
