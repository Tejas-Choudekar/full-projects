package com.lti.training.day6.streams;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationExample {
	private static void serialize() throws Exception{
		FileOutputStream f = new FileOutputStream("emp.txt");
		ObjectOutputStream os = new ObjectOutputStream(f);
		
		Employee e = new Employee();
		e.setEmpno(1001);
		e.setName("Prathyusha");
		e.setSalary(25000);
		
		os.writeObject(e); 		//serialization i.e saving the state of an object
		
		os.close();
		f.close();
		
	}
private static void deserialize() throws Exception{
	
	FileInputStream f=new FileInputStream("emp.txt");
	ObjectInputStream os=new ObjectInputStream(f);
	
	Employee e=(Employee) os.readObject();
	
	System.out.println(e.getEmpno());
	System.out.println(e.getName());
	System.out.println(e.getSalary());
	
	os.close();
	f.close();
	
	}
public static void main(String[] args) throws Exception {
	serialize();
	deserialize();
}

}
