class Phone{
	String keyboard="in-built";
	void sub(int x,int s) {
		System.out.println(x+s);
	}

}
class Tablet extends Phone{
	boolean playMovie=false;
	void sub(int x, int y) {
		System.out.println(x+y);
	}
	public static void main(String[] args) {
		Phone p=new Tablet();
		//System.out.println(p.keyboard+":"+p.playMovie);
		p.sub(2, 3);
		p.sub(2,2);
	}
}
//public class Test extends Tablet {
	
//}
