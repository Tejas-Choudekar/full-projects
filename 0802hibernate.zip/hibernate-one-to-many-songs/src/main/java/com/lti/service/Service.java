package com.lti.service;

import java.util.Date;
import java.util.List;

import com.lti.dao.AlbumDao;
import com.lti.dao.GenericDao;
import com.lti.entity.Albums;
import com.lti.entity.Songs;

public class Service {
	public void addAlbum(String name, Date release_date, String copyright) {
		Albums alb = new Albums();
		alb.setName(name);
		alb.setRelease_date(release_date);
		alb.setCopyright(copyright);
		
		GenericDao dao= new GenericDao();
		dao.store(alb);
	}
	
	public void addSongs(String name, double duration, String singer, int album_id) {
		GenericDao dao = new GenericDao();
		Albums alb=dao.fetchById(Albums.class, album_id);
		Songs song = new Songs();
		song.setName(name);
		song.setDuration(duration);
		song.setSinger(singer);
		song.setAlbum(alb);
		
		dao.store(song);
	}
	
	public List<Songs> fetchAlbum(int id){
		AlbumDao dao = new AlbumDao();
		return dao.fetchAlbum(id);
	}
	

}
