package com.lti.training.day7.jdbc;


import java.util.List;
import java.util.Scanner;

import com.lti.training.day6.streams.Employee;

public class TestDao {

	public static void main(String[] args) throws DataAccessException {
		Scanner sc=new Scanner(System.in);
		Employee emp=new Employee();
		System.out.println("Enter emp no.: ");
		int empno=sc.nextInt();
		System.out.println("Enter emp name: ");
		String name=sc.next();
		System.out.println("Enter emp salary: ");
		double salary=sc.nextDouble();
		emp.setEmpno(empno);
		emp.setName(name);
		emp.setSalary(salary);
		EmployeeDao em=new EmployeeDao();
		em.store(emp);
		//em.display();
		try {
			List<Employee> list=	em.fetchAll();
			for(Employee e : list) {
				System.out.print(e.getEmpno());
				System.out.print("\t"+e.getName());
				System.out.println("\t"+e.getSalary());
			}		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
