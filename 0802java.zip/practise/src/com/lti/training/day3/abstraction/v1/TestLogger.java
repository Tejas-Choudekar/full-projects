package com.lti.training.day3.abstraction.v1;

public class TestLogger {

	public static void main(String[] args) {
		Logger logger=new Logger();
		logger.log("Some message");
		logger.log("Some message", LogLevel.WARN);
		logger.log("Some concern to be addressed", LogLevel.INFO);
		logger.log("Some critical situation has arised", LogLevel.ERROR);

	}

}
