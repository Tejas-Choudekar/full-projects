package com.lti.training.day2.basics;

public class PBMain {

	public static void main(String[] args) {
		Contact c1=new Contact("Ketki", "9876543218", "Ketki.shendye@gmail.com","03/10/1996");
		Contact c2=new Contact("Ankita", "9876543218", "ankita.delukar@gmail.com", "09/07/1996");
	//	Contact c3=new Contact("Ketki", "9876543218", "Ketki@gmail.com","03/10/1996");
		PhoneBook pb=new PhoneBook();
		pb.add(c1);
		pb.add(c2);

	//	pb.add(c3);
		//pb.Display();
		
		Contact c5=	pb.searchByName("jhg");
		if(c5!=null)
		System.out.println("Name-"+c5.getName()+"\temail--"+c5.getEmail());
		else
			System.out.println("no record found");
		Contact c4=pb.searchByNumber("9876543218");
		System.out.println("Number-"+c4.getNumber()+"Name-"+c4.getName()+"\temail--"+c4.getEmail());
		
		Contact c6=new Contact("Ketki", "666666", "Ketki.shendye@gmail.com","03/10/1996");
		pb.update(c6);
		pb.Display();
		
		

	}

}
