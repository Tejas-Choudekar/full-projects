package com.lti.training.day2.basics;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class Dateandtime {
	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss a");
		TimeZone	tz =TimeZone.getTimeZone("America/New_York");
		sdf.setTimeZone(tz);
	
		
		Calendar c =Calendar.getInstance(tz);
		sdf.format(c.getTime());
	//	System.out.println(c.get(Calendar.HOUR_OF_DAY)+":"+c.get(Calendar.MINUTE)+":"+(Calendar.AM_PM));
	System.out.println(sdf.format(c.getTime()));
	

	}
}
