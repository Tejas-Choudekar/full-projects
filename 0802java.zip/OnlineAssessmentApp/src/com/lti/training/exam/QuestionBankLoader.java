package com.lti.training.exam;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuestionBankLoader {

	private QuestionBank questionBank;
	
	public QuestionBankLoader() {
		questionBank= new QuestionBank();
		
	}
	 
	public List<Question> loadQuestionsOnJava() {
		questionBank.addNewSubject("Java");
		
		Question q= new Question();
		q.setQuestion("What is a class?");
		List<Option> options= new ArrayList<>();
		Option o1 = new Option("Class is a template", true);
		Option o2 = new Option("Class is a classroom", false);
		Option o3 = new Option("Class is a datatype", false);
		Option o4 = new Option("Class is a class", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("What is an object?");
		options= new ArrayList<>();
		o1 = new Option("Object is a template", false);
		o2 = new Option("Object is a classroom", false);
		o3 = new Option("Object is instance of class", true);
		o4 = new Option("Object is a class", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("What is a collection?");
		options= new ArrayList<>();
		o1 = new Option("Collection is a template", false);
		o2 = new Option("Collection is a framework which groups multiple elements into single unit", true);
		o3 = new Option("Collection is a datatype", false);
		o4 = new Option("Collection is a class", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("Which of this method is given parameter via command line arguments?");
		options= new ArrayList<>();
		o1 = new Option("main()", true);
		o2 = new Option("recursive() method", false);
		o3 = new Option("Any method", false);
		o4 = new Option("System defined methods", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("Which of these data types is used to store command line arguments?");
		options= new ArrayList<>();
		o1 = new Option(" Array", false);
		o2 = new Option(" Stack", false);
		o3 = new Option("String",true);
		o4 = new Option("Integer", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("Which of these is a correct statement about args in this line of code?\n public static void main(String args[])");
		options= new ArrayList<>();
		o1 = new Option("args is a String", false);
		o2 = new Option("args is a Character", false);
		o3 = new Option("args is an array of String",true);
		o4 = new Option("args in an array of Character", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("How do we pass command line argument in Eclipse?");
		options= new ArrayList<>();
		o1 = new Option(" Arguments tab", true);
		o2 = new Option("Variable tab", false);
		o3 = new Option("Cannot pass command line argument in eclipse", false);
		o4 = new Option("Environment variable tab", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("Which annotation is used to represent command line input and assigned to correct data type?");
		options= new ArrayList<>();
		o1 = new Option("@Input", false);
		o2 = new Option("@Parameter", true);
		o3 = new Option("@Variable", false);
		o4 = new Option("@Command Line", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
				
		return questionBank.getQuestionsFor("Java");
	}
	
}
