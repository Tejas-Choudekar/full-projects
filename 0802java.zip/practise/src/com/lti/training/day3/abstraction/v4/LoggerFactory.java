package com.lti.training.day3.abstraction.v4;  // added factory class for achieving abstraction and changing the objects in multiple places

public class LoggerFactory {
	public static Logger getLoggerInstance() {
		return new ConsoleLogger();
	}

}
