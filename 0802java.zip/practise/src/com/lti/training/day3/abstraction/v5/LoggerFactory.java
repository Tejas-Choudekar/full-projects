package com.lti.training.day3.abstraction.v5;

public class LoggerFactory {
	public static Logger getLoggerInstance() {
		return new ConsoleLogger();
	}

}
