package com.lti.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lti.training.dao.FlightDao;
import com.lti.training.model.Flight;

/**
 * Servlet implementation class FlightListServlet
 */
//@WebServlet("/FlightListServlet")
public class FlightListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String from=request.getParameter("from");
		String to=request.getParameter("to");
		String date=request.getParameter("date");
				
		FlightDao dao=new FlightDao();
		List<Flight> flights=dao.getFlightDetails(from,to,date);
		
		ObjectMapper mapper = new ObjectMapper(); 
		String flightJSON = mapper.writeValueAsString(flights); 
		
		response.setContentType("application/json");
		response.setHeader("Access-Control-Allow-Origin", "http://localhost:4200");
		response.setHeader("Access-Control-Allow-Methods", "GET");
		PrintWriter out = response.getWriter();
		out.write(flightJSON);
		
		
	}

}
