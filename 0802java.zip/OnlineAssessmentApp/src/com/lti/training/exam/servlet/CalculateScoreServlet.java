package com.lti.training.exam.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lti.training.exam.Option;
import com.lti.training.exam.Question;

/**
 * Servlet implementation class CalculateScoreServlet
 */
@WebServlet("/CalculateScoreServlet")
public class CalculateScoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		Question q = (Question) session.getAttribute("currentQs");
		
		int selectedOptionNo = Integer.parseInt(request.getParameter("option"));
		Integer score = (Integer) session.getAttribute("updatedScore");
		if(score == null)
			score=0;
		
		Option selectedOption = q.getOptions().get(selectedOptionNo);
		if(selectedOption.isRightAnswer())
			score++;

		session.setAttribute("updatedScore", score);
		
		response.sendRedirect("LoadQuestionServlet");
	}

}
