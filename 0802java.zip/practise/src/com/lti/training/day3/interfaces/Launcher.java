package com.lti.training.day3.interfaces;

/**
 * 
 * @author google
 *
 */

public class Launcher {
	private TaskManager taskManager;			// declared an object
	public Launcher() {
		taskManager= new TaskManager();		// created an object
	}

	public void launch(MobileApplication mobileApp)			//mobileApp is an object and is accepting app1 and app2 from TestMobileApp class and passing it to start().
	{
		mobileApp.start();
		taskManager.newAppLoaded(mobileApp);
		//mobileApp.pause();
		//mobileApp.stop();
	}
	public int runningAppsCount() {
		return taskManager.getNumberOfRunningApps();
	}
	
	public void closeAllApps() {
		taskManager.closedRunningApps();
	}
}
