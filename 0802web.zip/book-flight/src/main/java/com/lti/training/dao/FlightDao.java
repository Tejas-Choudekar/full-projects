package com.lti.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.training.model.Flight;


public class FlightDao {
	public List<Flight> getFlightDetails(String from, String to, String date){
		Connection conn=null;		
		PreparedStatement pstmt= null; 		
		ResultSet rs = null;
		List<Flight> flight = new ArrayList<Flight>(); 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
			pstmt=conn.prepareStatement("select * from flights where from_loc=? and to_loc=? and journ_date=?");
			pstmt.setString(1, from);
			pstmt.setString(2, to);
			pstmt.setString(3, date);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Flight f=new Flight();
				f.setFrom(rs.getString("from_loc"));
				f.setTo(rs.getString("to_loc"));
				f.setDate(rs.getString("journ_date"));
				f.setFlight_no(rs.getInt("flight_no"));
				f.setFlight_name(rs.getString("flight_name"));
				flight.add(f);
			}
			return flight;
		}
		catch(ClassNotFoundException | SQLException  e) {
			e.printStackTrace();
			return null;
		}
		finally {
			try {rs.close();} catch(Exception e) {}
			try {pstmt.close();} catch(Exception e) {}
			try {conn.close();} catch(Exception e) {}
		}
	}
}
