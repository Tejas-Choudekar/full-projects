package com.lti.training.day4.asign;

import com.lti.training.day4.pack1.Class1;

public class Class4 extends Class1{
	void check() {
		//System.out.println(a);
		//System.out.println(b);		//default
		System.out.println(c);		//protected
		System.out.println(d);
	}
}
