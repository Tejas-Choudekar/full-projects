package com.lti.training.day5.collections;

import java.util.ArrayList;
import java.util.List;

public class UserManager {

	private List<User> users;
	private User user;
	public UserManager() {
		users=new ArrayList<User>();
		users.add(new User("priti","123"));
		users.add(new User("tejas","789"));
		users.add(new User("laxmi","456"));
		users.add(new User("kanchan","147"));
	}
	
	public boolean isValidUser(String username,String password) {
		for(User u:users)
			if(u.getUsername().equals(username) && u.getPassword().equals(password))
				return true;		
		
		return false;
	}
	
	public static void main(String[] args) {
		UserManager userMang=new UserManager();
		boolean isValid=userMang.isValidUser("laxmi", "147");
		System.out.println(isValid);
	}
}
