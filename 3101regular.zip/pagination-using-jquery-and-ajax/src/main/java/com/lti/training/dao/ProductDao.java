package com.lti.training.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.lti.training.model.Product;

public class ProductDao {
	public List<Product> fetchProducts(int from, int to){
		Connection conn=null;		// will start connection
		PreparedStatement pstmt= null; 		//precompiled sql statements (help us fire sql statements)
		ResultSet rs = null;
		List<Product> prod = new ArrayList<Product>(); 
		try {
			InputStream is =this.getClass().getClassLoader().getResourceAsStream("dev-db.properties");
			Properties prop = new Properties();
			prop.load(is);
			
			String driverClassName=prop.getProperty("driverClassName");
			String url=prop.getProperty("url");
			String username=prop.getProperty("username");
			String password=prop.getProperty("password");
			
			Class.forName(driverClassName);
			conn = DriverManager.getConnection(url,username,password);
			pstmt= conn.prepareStatement("select * from (select pr.*, rownum r from product pr) where r between ? and ?");
			pstmt.setInt(1, from);
			pstmt.setInt(2, to);
			rs=pstmt.executeQuery();	
			while(rs.next()) {
				int id=rs.getInt("id");
				String name=rs.getString("name");
				double price=rs.getDouble("price");
				int quantity=rs.getInt("quantity");
				Product p=new Product();
				p.setId(id);
				p.setName(name);
				p.setPrice(price);
				p.setQuantity(quantity);
				prod.add(p);
			}
			return prod;
		}
		catch(ClassNotFoundException | SQLException | IOException  e) {
			e.printStackTrace();
			return null;
		}
		finally {
			try {rs.close();} catch(Exception e) {}
			try {pstmt.close();} catch(Exception e) {}
			try {conn.close();} catch(Exception e) {}
		}
	}
}
