package com.lti.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;
//import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.training.service.DatabaseUserService;

/**
 * Servlet implementation class HomePageServlet
 */
@WebServlet("/HomePageServlet")
public class HomePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 out.println("<html><body>");
		 out.println("<h1>Welcome to abc.com</h1>");
		 String page = "login.html";
		// checking if cookies are present 
		Cookie[] cookies = request.getCookies();
		
		if(cookies != null) {
			String username = "", password="";
			for(Cookie cookie: cookies) {
				if(cookie.getName().equals("uname"))
					username = cookie.getValue();
				if(cookie.getName().equals("upass"))
					password = cookie.getValue();
			}
			DatabaseUserService userService = new DatabaseUserService();
			boolean isValid = userService.validateUser(username, password);
			if(isValid) 
				page="welcome.html";
		
		}
		out.println("<a href=' " + page +  " ' >Click here</a> to continue");
		out.println("</body></html>");
	}
	
}
