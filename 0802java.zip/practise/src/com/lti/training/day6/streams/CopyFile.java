package com.lti.training.day6.streams;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyFile {
	
	public static void main(String[] args) {
		FileInputStream inFile = null;
		FileOutputStream outFile= null;
		//FileReader inFile=null;
		//FileWriter outFile=null;
		try {
			//inFile = new FileInputStream("sample.txt");
			//outFile = new FileOutputStream("outsample.txt");
			//inFile = new FileInputStream("LTI_logo.jpg");
			//outFile = new FileOutputStream("LTI.jpg");
			inFile = new FileInputStream("D:\\jdk-8u131-windows-x64.exe");
			outFile = new FileOutputStream("D:\\\\jdk-8u131-windows-x64-copy.exe");
			//inFile = new FileReader("LTI_logo.jpg");
			//outFile = new FileWriter("LTI.jpg");
			int ch=0;
			while(true) {
				ch= inFile.read();
				if(ch== -1)	//End Of File
					break;
				outFile.write(ch);
				//System.out.print((char)ch);		
			}
			System.out.println("File copy jhali!!!");
		}
		catch(FileNotFoundException e) {
			System.out.println("Please check the no. of your glasses");
		}
		catch(IOException e) {
			System.out.println("Please contact Mr. Santosh, HDD corrupted");
		}
		finally {
			try { inFile.close();} catch (Exception e) {}
			try { outFile.close();} catch (Exception e) {}
		}
	}
}

/* Know where to use InputStream OutputStream and reader writer,
 * Inpurstream Outputstream reads data in bit by bit form but reader writer uses char by char i.e byte by byte
 * so using reader/writer for jpg or any non text file handeling may cause error. so be careful.*/


