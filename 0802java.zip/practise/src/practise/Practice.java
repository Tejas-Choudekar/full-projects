package practise;

public class Practice implements PracInterface{
	public void Test (int a) {
		System.out.println("Number is : "+a);
	}
	public void Cook(int a)
	{
		
	}
	public void Essay(int a)
	{
		
	}
	public void Play(int a)
	{
		
	}
	
	public static void main(String[] args) {
		Practice p= new Practice();
		p.Test(50);
		p.sleep(50);

	}

}
