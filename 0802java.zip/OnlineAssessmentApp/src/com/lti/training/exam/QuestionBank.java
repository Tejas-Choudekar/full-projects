package com.lti.training.exam;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestionBank {

	private Map<String, List<Question>> questionBank;
	/* String will represent name of subject and List will store all the questions for all the subjects
	 * so in Map the key is Name of the subject and value is the list of questions*/
	public QuestionBank() {
		questionBank = new HashMap<>();
	}
	
	public void addNewSubject(String subject) {
		questionBank.put(subject,  new ArrayList<>());
		/* Subject is a key, for example Java and ArrayList will add questions for that key, here ArrayList will be empty
		 * this method will add subject name to an empty list*/
	}
	public void addNewQuestion(String subject,Question question) {
		List<Question> questions=questionBank.get(subject);
		questions.add(question);
		/* Here get(Subject) will get the key and assign list of questions as values to that subject name(Key)*/
		
	}
	
	public List<Question> getQuestionsFor (String subject)
	{
		return questionBank.get(subject);
	}
	
	
}
