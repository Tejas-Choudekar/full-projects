package com.lti.training.day5.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.lti.training.day3.objectclass.Person;

public class ExampleOnList {

	public static void main(String[] args) {
		List<String> list1 = new ArrayList<>();
		// <> angular brace notation is called Generics in Java, we can ignore it or write the code without it
		/* these generics will add type security, following data might contain integer also, this will lead to bugs so we use generics 
		 * to add type security*/
		
		list1.add("Java");
		list1.add("Oracle");
		list1.add("Dotnet");
		list1.add("PHP");
		list1.add("Java");
		list1.add("Ek aur");
		
		// Different ways of iterating over the List
		
		System.out.println("Option 1: old fashioned for loop");		//Unsafe as there are concurrency issues so we use the rest in projects even though this is fast
		for(int i=0; i<list1.size(); i++)
			System.out.println(list1.get(i));
		
		System.out.println("Option 2: Using for-each loop");
		for(String str : list1)
			System.out.println(str);
		
		System.out.println("Option 3: Java 8 lambda style for-each loop");
		list1.forEach(str -> System.out.println(str));
		
		System.out.println("Option 4: Traditional iterator");
		Iterator<String> itr = list1.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		
		List<Person> list2= new ArrayList<>();
		
		list2.add(new Person("Prathyusha", 22));
		list2.add(new Person("Tejas", 22));
		list2.add(new Person("Some one else", 24));
		list2.add(new Person("Any one", 32));
		
		System.out.println("Array list using objects");
		for(Person det : list2)
			System.out.println(det);
		
		
		List<String> list3 = new ArrayList<>();
		list3.add("Java2");
		list3.add("Oracle2");
		list3.add("Dotnet2");
		list3.add("PHP2");
		list3.add("Java2");
		list3.add("Ek aur2");
		
		System.out.println("\n\n Array list using objects printed using iterator");
		Iterator<Person> per= list2.iterator();
		while(per.hasNext())
			System.out.println(per.next());
		
		//Assignment
		
		list2.add(3, new Person("Kanchan",21));
		System.out.println("Array list using objects");
		for(Person det : list2)
			System.out.println(det);
		
		list1.addAll(2, list3);
		System.out.println("Array list using objects");
		for(String ails : list1)
			System.out.println(ails);
		
		System.out.println("\n\n"+list1.containsAll(list3));
		
		System.out.println("\n\n"+list1.get(5));
		System.out.println("\n\n"+list1.hashCode());
	}

}
