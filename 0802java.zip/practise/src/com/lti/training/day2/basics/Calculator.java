package com.lti.training.day2.basics;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.Year;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import javax.xml.bind.SchemaOutputResolver;

public class Calculator {
	public static void add(int x, int y) {
		System.out.println(x+y);
	
	} 
	public static void sub(int x,int y) {
		System.out.println(x-y);
	}
	public static void main(String[] args) {
	//	Calculator c=new Calculator();
	//	c.add(10,20);
	//	c.sub(10, 20);
		//Calculator.add(10, 20);
	//	Calculator.sub(10, 20);
		
	//	LocalDate d=new LoaclDate();
		SimpleDateFormat formatter =new SimpleDateFormat("MM/dd/yyyy");
		//System.out.println(d);
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Date ");
		String date = scanner.next();
	
		SimpleDateFormat formatter1 =new SimpleDateFormat("yyyy");
		Date d=new Date();
		Date myDate;
	//	Date enter=null;
		//formatter1.format(d);
	
		/*try {
			
			myDate=formatter.parse(date);
		
		int a=Integer.parseInt(formatter1.format(d));
		int b=Integer.parseInt(formatter1.format(myDate));
			int age=a-b;
			System.out.println(age);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int dd=3;
		int mm=10;
		int yyyy=1996;
		Calendar cal=Calendar.getInstance();
		cal.set(yyyy,mm-1,dd);
		int day=cal.get(Calendar.DAY_OF_WEEK);
		String[ ] days= {"SUN","MON","TUES","WED","THUS","FRI","SAT"};
		System.out.println("Days "+days[day-1]);*/
		
		
		LocalDate birthdate =  LocalDate.of (1970, 1, 20);
		LocalDate now =  LocalDate.now();
   Period p=	Period.between(birthdate, now);
   System.out.println(p.getYears());
	//	Year age = Year.yearsBetween(birthdate, now);
		
		
		
	}

}
