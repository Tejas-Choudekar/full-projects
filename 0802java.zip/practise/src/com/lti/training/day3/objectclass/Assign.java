package com.lti.training.day3.objectclass;

public class Assign {

	public static void main(String[] args) throws CloneNotSupportedException {
		Battery b1=new Battery(10);
		Battery b2=new Battery(20);
		Battery b3=new Battery(30);
		Toy t=new Toy();
		t.add(b1);
		t.add(b2);
		t.add(b3);
		
		System.out.println("The battery num:"+b1.getBattery());
		Battery b= (Battery) b1.clone();
		System.out.println(b);
		
		System.out.println("The toy battery numbers are:"+t.getBat());
		Toy t1=(Toy) t.clone();
		System.out.println(t1);
	}

}
