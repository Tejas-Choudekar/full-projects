package com.lti.training.day5.collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuestionBankLoader {

	private QuestionBank questionBank;
	
	public QuestionBankLoader() {
		questionBank= new QuestionBank();
		
	}
	 
	public void loadQuestionsOnJava() {
		questionBank.addNewSubject("Java");
		
		Question q= new Question();
		q.setQuestion("What is a class?");
		List<Option> options= new ArrayList<>();
		Option o1 = new Option("Class is a template", true);
		Option o2 = new Option("Class is a classroom", false);
		Option o3 = new Option("Class is a datatype", false);
		Option o4 = new Option("Class is a class", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("What is an object?");
		options= new ArrayList<>();
		o1 = new Option("Object is a template", false);
		o2 = new Option("Object is a classroom", false);
		o3 = new Option("Object is instance of class", true);
		o4 = new Option("Object is a class", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
		q= new Question();
		q.setQuestion("What is a collection?");
		options= new ArrayList<>();
		o1 = new Option("Collection is a template", false);
		o2 = new Option("Collection is a framework which groups multiple elements into single unit", true);
		o3 = new Option("Collection is a datatype", false);
		o4 = new Option("Collection is a class", false);
		
		options.add(o1);
		options.add(o2);
		options.add(o3);
		options.add(o4);
		
		q.setOptions(options);
		questionBank.addNewQuestion("Java", q);
		
	}
	
public void startExam() {
	Scanner sc= new Scanner(System.in);
	List<Question> questions = questionBank.getQuestionsFor("Java");
	int score=0;
	// will show the list of the questions to user
	for(Question question : questions) {
		System.out.println("\n\n Q."+question.getQuestion());
		for(Option option:question.getOptions())
			System.out.println(option.getOption());
		System.out.println("Enter your response(1-4) ");
		int ans=sc.nextInt();
		Option selectedOption=question.getOptions().get(ans-1);
		if(selectedOption.isRightAnswer())
			score++;
		//for(Option option: question.getOptions())
		//ans.equals(option.);
		
	}
	System.out.println("\n Your score is:"+score);
	
		
	}

public static void main(String[] args) {
	QuestionBankLoader qbl= new QuestionBankLoader();
	qbl.loadQuestionsOnJava();
	qbl.startExam();
}
}
