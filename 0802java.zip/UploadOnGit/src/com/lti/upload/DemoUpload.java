package com.lti.upload;

public class DemoUpload {

	public static void main(String[] args) {
		System.out.println("Uploading to git");

	}

}
