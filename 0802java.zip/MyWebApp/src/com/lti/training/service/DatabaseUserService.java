package com.lti.training.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DatabaseUserService {
	
public boolean validateUser (String username,String password) {
	Connection conn=null;		// will start connection
	PreparedStatement pstmt= null; 		//precompiled sql statements (help us fire sql statements)
	ResultSet rs=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
		pstmt= conn.prepareStatement("select * from login where username=? and password=?");
		pstmt.setString(1, username);
		pstmt.setString(2, password); 
		rs=pstmt.executeQuery();	
		while(rs.next()){
			/*String active=rs.getString("active");
			if(active.equals("Y"))
				return true;*/
			if(rs.getString("username").equals(username)) {
				String pwd=rs.getString("password");
				if(pwd.equals(password))
					return true;
			}
		}
		return false;
	}
	catch(ClassNotFoundException | SQLException e) {
		System.out.println("Problem while inserting employee data");
		return false;
	}
	finally {
		try {rs.close();} catch(Exception e) {}
		try {pstmt.close();} catch(Exception e) {}
		try {conn.close();} catch(Exception e) {}
	}
}
public boolean validatePassword(String password, String cnf_password) {
	if(password.equals(cnf_password))
		return true;
	return false;
	
}


public void addData (String username,String password) {
	Connection conn=null;		// will start connection
	PreparedStatement pstmt= null; 		//precompiled sql statements (help us fire sql statements)
	ResultSet rs=null;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
		pstmt= conn.prepareStatement("insert into login(username, password) values(?,?)");
		pstmt.setString(1, username);
		pstmt.setString(2, password);
		pstmt.execute();	
		/*while(rs.next()){
			/*String active=rs.getString("active");
			if(active.equals("Y"))
				return true;
			if(rs.getString("username").equals(username)) {
				String pwd=rs.getString("password");
				if(pwd.equals(password))
					if(rs.getString("active").equals("Y"))
						return true;
			}
		}
		return false;*/
	}
	catch(ClassNotFoundException | SQLException e) {
		System.out.println("Problem while inserting employee data");
	}
	finally {
		try {rs.close();} catch(Exception e) {}
		try {pstmt.close();} catch(Exception e) {}
		try {conn.close();} catch(Exception e) {}
	}
}
}
