package com.lti.training.day2.basics;

public class conversion {
	public static void main(String[] args) {
		int x=65;
		System.out.println("65 to binary-"+Integer.toBinaryString(x));
		System.out.println("65 to Hex-"+Integer.toHexString(x));
		System.out.println("65 to octal-"+Integer.toOctalString(x));
		
	}

}
