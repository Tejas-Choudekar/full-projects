package com.lti.training.day3.interfaces;

public class TestMobileApp {

	public static void main(String[] args) {
		MyMobileApplication app1= new MyMobileApplication();
		MyMobileApplication2 app2= new MyMobileApplication2();
		
		Launcher launcher = new Launcher();
		launcher.launch(app2);
		launcher.launch(app1);
		System.out.println(launcher.runningAppsCount());
		
		launcher.closeAllApps();
	}

}
