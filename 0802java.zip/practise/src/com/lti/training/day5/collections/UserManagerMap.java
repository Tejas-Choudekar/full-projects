package com.lti.training.day5.collections;

import java.util.HashMap;
import java.util.Map;

public class UserManagerMap {

	private Map<String, String> users;
	
	public UserManagerMap() {
		users=new HashMap<>();
		users.put("priti","123");
		users.put("tejas","789");
		users.put("laxmi","456");
		users.put("kanchan","147");
	}
	
	public boolean isValidUser(String username,String password) {
		if(users.containsKey(username)) {
			String pwd=users.get(username);
			if(pwd.equals(password))
				return true;
		}
		return false;
	}
	
	public static void main(String[] args) {
		UserManagerMap userMang=new UserManagerMap();
		boolean isValid=userMang.isValidUser("laxmi", "147");
		System.out.println(isValid);
	}
}
