package com.lti.training.day6.streams;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/*
 * This program copies the data of one text file to another using buffering
 */
public class FastCopyCSVFile {
	
	public static void main(String[] args) {
		FileReader inFile = null;
		FileWriter outFile1= null;
		FileWriter outFile2= null;
		FileWriter outFile3= null;
		
		BufferedReader inBuffer=null;
		BufferedWriter outBuffer1=null;
		BufferedWriter outBuffer2=null;
		BufferedWriter outBuffer3=null;
		
		try {
			inFile = new FileReader("C:\\Users\\vshadmin\\Desktop\\emp.csv");
			outFile1 = new FileWriter("C:\\\\Users\\\\vshadmin\\\\Desktop\\empno.txt");
			outFile2 = new FileWriter("C:\\\\Users\\\\vshadmin\\\\Desktop\\empname.txt");
			outFile3 = new FileWriter("C:\\\\Users\\\\vshadmin\\\\Desktop\\empsal.txt");
			
			
			inBuffer=new BufferedReader(inFile);  //default size of buffer us 8kb
			outBuffer1=new BufferedWriter(outFile1);
			outBuffer2=new BufferedWriter(outFile2);
			outBuffer3=new BufferedWriter(outFile3);

			String line = null;
			while(true) {
				line= inBuffer.readLine();
				if(line== null)	//End Of File
					break;
				String Empdet[]=line.split(",");
				//to add generated character on new line.
				System.out.println(line);		
				int i=0;

				outBuffer1.write(Empdet[i]);
				outBuffer1.newLine();
						outBuffer2.write(Empdet[i++]);
						outBuffer2.newLine();
						outBuffer3.write(Empdet[i++]);
						outBuffer3.newLine();
				
				
			}
			System.out.println("File copy jhali!!!");
		}
		catch(FileNotFoundException e) {
			System.out.println("Please check the no. of your glasses");
		}
		catch(IOException e) {
			System.out.println("Please contact Mr. Santosh, HDD corrupted");
		}
		finally {
			try { inBuffer.close();} catch (Exception e) {}
			try { outBuffer1.close();} catch (Exception e) {}
			try { outBuffer2.close();} catch (Exception e) {}
			try { outBuffer3.close();} catch (Exception e) {}
			try { inFile.close();} catch (Exception e) {}
			try { outFile1.close();} catch (Exception e) {}
			try { outFile2.close();} catch (Exception e) {}
			try { outFile3.close();} catch (Exception e) {}
		}
	}
}

/* Know where to use InputStream OutputStream and reader writer,
 * Inpurstream Outputstream reads data in bit by bit form but reader writer uses char by char i.e byte by byte
 * so using reader/writer for jpg or any non text file handeling may cause error. so be careful.*/





