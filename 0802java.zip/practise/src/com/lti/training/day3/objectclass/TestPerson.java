package com.lti.training.day3.objectclass;

public class TestPerson {

	public static void main(String[] args) throws CloneNotSupportedException {
		Person p=new Person();
		p.setName("Priti");
		p.setAge(22);
		
		System.out.println(p.getName()+","+p.getAge());
		System.out.println("Name");
		System.out.println(p);
		
		Person p1=new Person("Priti",22);
		System.out.println(p==p1);			// compares memory address not values, only reference comparison is being carried out here
		System.out.println(p.equals(p1));			// compares memory address not values, only reference comparison is being carried out here
		System.out.println(p1.hashCode());
		System.out.println(p.hashCode());
		
		
		int h = 0;
		char[] ch = {'M','a','j','r','u','l'};
		  for (int i = 0; i < ch.length; i++) {
              h = 31 * h + ch[i];
          }
		  
		  System.out.println(h);
		
		  Person p2=(Person) p.clone();
		  System.out.println(p2);
		  
		  Address add=new Address("Mumbai", 4000081);
		  Person p3= new Person("Pratyusha", 22, add);
		  System.out.println(p3);
		  // shallow cloning
		  Person p4=(Person) p3.clone();
		  System.out.println("City="+ p3.getAddress().getCity());
		  System.out.println("City="+ p4.getAddress().getCity());
		  p4.getAddress().setCity("Delhi");
		  System.out.println("City="+ p3.getAddress().getCity());
		  System.out.println("City="+ p4.getAddress().getCity());
		  
		  p=null;
		  p1=null;
		  p2=null;
		  p3=null;
		  p4=null;
		  System.gc(); 					// never used in live projects
		  
	}

}
