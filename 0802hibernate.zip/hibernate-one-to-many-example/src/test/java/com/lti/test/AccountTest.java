package com.lti.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.lti.entity.Account;
import com.lti.entity.AccountTransaction;
import com.lti.service.AccountService;

public class AccountTest {

	@Test
	public void openAccount() {
		AccountService acc = new AccountService();
		acc.openAccount("John","Saving",10000);
		acc.openAccount("Stephen","Current",150000);
		acc.openAccount("Stacy","Saving",20000);
		acc.openAccount("June","Current",200000);
		assertNotNull(acc);
	}
	
	@Test
	public void withdraw() {
		AccountService sc = new AccountService();
		double amount=500;
		int acno= 61;
		sc.withdraw(acno, amount);
		//assertNotNull(sc);
	}
	
	@Test
	public void deposit() {
		AccountService sc = new AccountService();
		double amount=1500;
		int acno= 62;
		sc.deposit(acno, amount);
	}

	@Test
	public void transfer() {
		AccountService sc= new AccountService();
		double amount=2000;
		int fromac=63;
		int toac=62;
		sc.transfer(fromac, toac, amount);
	}
	
	@Test
	public void balance() {
		AccountService sc= new AccountService();
		int acno=63;
		System.out.println(sc.balance(acno));
	}
	
	@Test
	public void miniStatement(){
		AccountService sc = new AccountService();
		for(AccountTransaction tx: sc.miniStament(62))
			System.out.println(tx);
	}
	
	@Test
	public void transactionFilter() {
		AccountService sc = new AccountService();
		for(Account ac: sc.transactionFilter("Withdraw", 1000))
			System.out.println(ac);
	}
	
	@Test
	public void transactionDetails() {
		AccountService sc = new AccountService();
		for(AccountTransaction ac: sc.transactionDetails("John"))
			System.out.println(ac);
	}
	
}
