package com.lti.training.day3.abstraction.v6; // added abstract key for making the methods to be overriding .


public interface Logger {
	// from java8 onwards ,interface can contain non-abstract and static methods as well
	public default void log(String msg)		// default is used for giving body for non-abstract methods and these methods can or cannot be overridden
	{
		log(msg,LogLevel.INFO);
	}
	public abstract void log(String msg, LogLevel level) ;
}
