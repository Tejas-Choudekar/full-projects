package com.lti.training.exam;


import java.util.List;

public class Question {

	private String question;
	private List<Option> options;
	
	/*1. Instead of List(a collection) we could have used array, but as collections can be dynamic in nature
	 * so one question can have 2 options another one can have 4 options so the dynamic nature of collection
	 * will be advantageous for us
	 * 2. We are creating an object of ArrayList but still declaring List i.e its parent class, just to achieve abstraction 
	 * and hide the complexity of code*/
	public Question() {
		
	}
	
	public Question(String question, List<Option> options) {
		super();
		this.question = question;
		this.options = options;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public List<Option> getOptions() {
		return options;
	}
	public void setOptions(List<Option> options) {
		this.options = options;
	}
}
